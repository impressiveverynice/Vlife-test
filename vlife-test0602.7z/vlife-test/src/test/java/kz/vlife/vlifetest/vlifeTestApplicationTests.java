package kz.vlife.vlifetest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class vlifeTestApplicationTests {

    @Test
    void contextLoads() {
    }

}
