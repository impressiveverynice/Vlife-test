package kz.vlife.vlifetest.service;

import kz.vlife.vlifetest.entity.OrderDetail;
import kz.vlife.vlifetest.repository.OrderDetailRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MerchantPersonalAccountServiceImpl implements MerchantPersonalAccountService{

    private final OrderDetailRepository orderDetailRepository;
    @Override
    public double calculateAverageChequeForGivenMerchantId(Long merchantId) {
        return collectOrderDetailListForGivenMerchantId(merchantId).stream()
                .mapToDouble(OrderDetail::getOrderValue)
                .average()
                .orElse(0.0);
    };

    @Override
    public List<OrderDetail> collectOrderDetailListForGivenMerchantId(Long merchantId) {
        List<OrderDetail> ordersDetailList = orderDetailRepository.findAllByMerchantId(merchantId);
        return ordersDetailList;
    }

    private Long getAuthenticatedMerchantId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            Object principal = authentication.getPrincipal();
            if (principal instanceof UserDetails) {
                // Assuming your UserDetails implementation has a method to get the merchant ID
                return ((YourUserDetails) principal).getMerchantId();
            }
        }
        return null;
    }
}
