
CREATE SCHEMA IF NOT EXISTS vlifeschema;

CREATE USER postgres WITH PASSWORD 'postgres';

GRANT ALL PRIVILEGES ON DATABASE vlifedb TO postgres;
